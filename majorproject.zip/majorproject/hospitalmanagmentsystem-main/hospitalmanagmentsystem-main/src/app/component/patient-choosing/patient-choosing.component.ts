import { Component } from '@angular/core';

@Component({
  selector: 'app-patient-choosing',
  standalone: false,
  templateUrl: './patient-choosing.component.html',
  styleUrl: './patient-choosing.component.css'
})
export class PatientChoosingComponent {

}
