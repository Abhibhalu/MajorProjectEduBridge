import { Component } from '@angular/core';

@Component({
  selector: 'app-adminchoosingpage',
  standalone: false,
  templateUrl: './adminchoosingpage.component.html',
  styleUrl: './adminchoosingpage.component.css'
})
export class AdminchoosingpageComponent {

}
