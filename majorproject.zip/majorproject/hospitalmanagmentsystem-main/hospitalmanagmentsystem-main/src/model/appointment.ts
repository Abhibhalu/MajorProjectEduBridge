export class appointment{


    appointmentid:number|null;
    appointmentDate:string;
    appointmentTime:string;

    constructor()
{
    this.appointmentid=null;
    this.appointmentDate="";
    this.appointmentTime="";
}


}
